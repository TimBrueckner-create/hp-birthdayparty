"""Render a local, georeferenced parchment basemap from the downloaded OSM XML."""
import xml.etree.ElementTree as ET, json, math, html
from pathlib import Path
root=ET.parse('/private/tmp/geheime-osm.xml').getroot()
nodes={n.attrib['id']:(float(n.attrib['lat']),float(n.attrib['lon'])) for n in root.findall('node')}
ways=[]
for w in root.findall('way'):
 tags={t.attrib['k']:t.attrib['v'] for t in w.findall('tag')}
 pts=[nodes[n.attrib['ref']] for n in w.findall('nd') if n.attrib['ref'] in nodes]
 if len(pts)>1:ways.append((tags,pts))
# North-up and local equirectangular projection; matching JS projection.
bounds={'south':51.0840,'north':51.0888,'west':13.6960,'east':13.7050}
W=1000; H=round(W*(bounds['north']-bounds['south'])/((bounds['east']-bounds['west'])*math.cos(math.radians((bounds['north']+bounds['south'])/2))))
def xy(p):return ((p[1]-bounds['west'])/(bounds['east']-bounds['west'])*W,(bounds['north']-p[0])/(bounds['north']-bounds['south'])*H)
def d(pts,close=False):return 'M'+' L'.join(f'{x:.2f},{y:.2f}' for x,y in map(xy,pts))+(' Z' if close else '')
parts=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}"><defs><pattern id="hatch" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(35)"><path d="M0 0V5" stroke="#67513a" stroke-width=".65" opacity=".55"/></pattern><pattern id="grass" width="25" height="25" patternUnits="userSpaceOnUse"><path d="m7 13 2-4 2 4m7 9 1-4 2 4" fill="none" stroke="#7c7850" stroke-width=".8" opacity=".5"/></pattern></defs><rect width="100%" height="100%" fill="#efe2bb"/>']
for tags,pts in ways:
 if tags.get('landuse') in ['grass','meadow','forest','recreation_ground'] or tags.get('leisure') in ['park','garden','playground','pitch']:
  parts.append(f'<path d="{d(pts,True)}" fill="#cac59a" fill-opacity=".45" stroke="#8b8157" stroke-width="1"/><path d="{d(pts,True)}" fill="url(#grass)"/>')
for tags,pts in ways:
 if 'building' in tags:
  parts.append(f'<path d="{d(pts,True)}" fill="url(#hatch)" stroke="#68513b" stroke-width="1.25"/>')
labels=set()
for idx,(tags,pts) in enumerate(ways):
 if 'highway' not in tags:continue
 minor=tags['highway'] in ['footway','path','cycleway','steps','service'];width=5 if minor else 13
 path=d(pts);parts.append(f'<path d="{path}" fill="none" stroke="#82694a" stroke-width="{width+2}"/><path d="{path}" fill="none" stroke="#f4e9c9" stroke-width="{width}"/>')
 name=tags.get('name')
 if name and name not in labels and not minor:
  labels.add(name)
  if xy(pts[0])[0]>xy(pts[-1])[0]:pts=pts[::-1]
  parts.append(f'<path id="road{idx}" d="{d(pts)}" fill="none"/><text fill="#463829" font-family="Georgia,serif" font-size="13" paint-order="stroke" stroke="#f4e9c9" stroke-width="3"><textPath href="#road{idx}" startOffset="12%">{html.escape(name)}</textPath></text>')
parts.append('</svg>')
Path('schnitzeljagd-test/assets/area-map.svg').write_text(''.join(parts))
meta={**bounds,'width':W,'height':H,'source':'© OpenStreetMap-Mitwirkende','license':'ODbL 1.0','retrieved':'2026-10-20','projection':'local-equirectangular','streets':sorted(labels)}
Path('schnitzeljagd-test/assets/map-meta.json').write_text(json.dumps(meta,ensure_ascii=False))
Path('design/osm-source.xml').write_bytes(Path('/private/tmp/geheime-osm.xml').read_bytes())
print(meta)
